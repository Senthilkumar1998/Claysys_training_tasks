﻿using Microsoft.AspNetCore.Http;

namespace FilmZone.Models
{
    public class AddFilm
    {
        //public string UserAccountID { get; set; }
        public string FilmName { get; set; }
        public string FilmActors { get; set; }
        public string FilmActress { get; set; }
        public string FilmDirectors { get; set; }
        public string FilmProducers { get; set; }
        public string FilmReleaseYear { get; set; }
        public string FilmLanguages { get; set; }
        public IFormFile File { get; set; }

    }

}
