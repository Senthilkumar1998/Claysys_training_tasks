﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FilmZone.Models
{
    public class Search
    {
        public string FilmName { get; set; }
    }
}
