﻿namespace FilmZone.Models
{
    public class Account
    {
        public string FullName { get; set; }
        public string Email { get; set; }
        public string Mobileno { get; set; }
        public string Country { get; set; }
        public string City { get; set; }
        public string Password { get; set; }
        public string ConfirmPassword { get; set; }
        public string Gender { get; set; }
        
    }

}
