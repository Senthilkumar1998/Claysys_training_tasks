﻿using FilmZone.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;

namespace FilmZone.Controllers
{
    public class FilmController : Controller
    {
        public static string ConnectionString
        {
            get
            {
                return ConfigurationManager.ConnectionStrings["FilmZoneDBConnection"].ConnectionString.ToString();
            }
        }

        SqlConnection connection;
        SqlCommand command = new SqlCommand();
        SqlDataReader Reader;
        public void getconnection()
        {
            connection = new SqlConnection(ConnectionString);
        }
        
        [HttpGet]
        public ActionResult AddFilm()
        {
            return View("AddFilm");
        }

        [HttpPost]
        public ActionResult SaveFilm(AddFilm addFilm)
        {
            byte[] bytes = null;
            if (addFilm.File.FileName != null)
            {
                    using (MemoryStream ms = new MemoryStream())
                    {
                        addFilm.File.OpenReadStream().CopyTo(ms);
                        bytes = ms.ToArray();
                    }
            }
            getconnection();
            connection.Open();
            string query = "INSERT INTO [dbo].[FilmDetails] ([FilmName],[FilmActors],[FilmActress],[FilmDirectors],[FilmProducers],[FilmReleaseYear],[FilmLanguages],[FilmPosterImageByte]) VALUES(@FilmName,@FilmActors,@FilmActress,@FilmDirectors,@FilmProducers,@FilmReleaseYear,@FilmLanguages,@FilmPosterImageByte)";
            command = new SqlCommand(query, connection);
            command.CommandType = CommandType.Text;
            command.Parameters.AddWithValue("@FilmName", addFilm.FilmName);
            command.Parameters.AddWithValue("@FilmActors", addFilm.FilmActors);
            command.Parameters.AddWithValue("@FilmActress", addFilm.FilmActress);
            command.Parameters.AddWithValue("@FilmDirectors", addFilm.FilmDirectors);
            command.Parameters.AddWithValue("@FilmProducers", addFilm.FilmProducers);
            command.Parameters.AddWithValue("@FilmReleaseYear", addFilm.FilmReleaseYear);
            command.Parameters.AddWithValue("@FilmLanguages", addFilm.FilmLanguages);
            command.Parameters.AddWithValue("@FilmPosterImageByte", bytes);
            command.ExecuteNonQuery();
            connection.Close();

            return View("/Views/Account/Main.cshtml");
        }

        public ActionResult Cancel()
        {
            return View("/Views/Account/Main.cshtml");
        }

        [HttpGet]
        public ActionResult FilmDashboard()
        {
            getconnection();            
            connection.Open();
            var model = new List<FilmDashboard>();
            string query = "SELECT [FilmID],[FilmName],[FilmActors],[FilmActress],[FilmDirectors],[FilmProducers],[FilmReleaseYear],[FilmLanguages],[FilmPosterImageByte] FROM FilmDetails";
                command = new SqlCommand(query, connection);
                Reader = command.ExecuteReader();
                while (Reader.Read())
                {
                var FilmDashboard = new FilmDashboard();
                FilmDashboard.FilmID = (int)Reader["FilmID"];
                FilmDashboard.FilmName =(string) Reader["FilmName"];
                FilmDashboard.FilmActors = (string)Reader["FilmActors"];
                FilmDashboard.FilmActress = (string)Reader["FilmActress"];
                FilmDashboard.FilmDirectors = (string)Reader["FilmDirectors"];
                FilmDashboard.FilmProducers = (string)Reader["FilmProducers"];
                FilmDashboard.FilmReleaseYear = (string)Reader["FilmReleaseYear"];
                FilmDashboard.FilmLanguages = (string)Reader["FilmLanguages"];
                FilmDashboard.FilmPosterImageByte = (byte[])Reader["FilmPosterImageByte"];
                FilmDashboard.FilmPosterImage = RetrieveFilmPoster(FilmDashboard.FilmPosterImageByte);
                model.Add(FilmDashboard);
            }
            connection.Close();            
            return View(model);
        }
        
        [HttpGet]
        public ActionResult Search(Search search)
        {
            getconnection();
            connection.Open();
            var model = new List<FilmDashboard>();
            string query = "SELECT [FilmID],[FilmName],[FilmActors],[FilmActress],[FilmDirectors],[FilmProducers],[FilmReleaseYear],[FilmLanguages],[FilmPosterImageByte] FROM FilmDetails where FilmName='" +search.FilmName+ "'";
            command = new SqlCommand(query, connection);
            Reader = command.ExecuteReader();
            while (Reader.Read())
            {
                var FilmDashboard = new FilmDashboard();
                FilmDashboard.FilmID = (int)Reader["FilmID"];
                FilmDashboard.FilmName = (string)Reader["FilmName"];
                FilmDashboard.FilmActors = (string)Reader["FilmActors"];
                FilmDashboard.FilmActress = (string)Reader["FilmActress"];
                FilmDashboard.FilmDirectors = (string)Reader["FilmDirectors"];
                FilmDashboard.FilmProducers = (string)Reader["FilmProducers"];
                FilmDashboard.FilmReleaseYear = (string)Reader["FilmReleaseYear"];
                FilmDashboard.FilmLanguages = (string)Reader["FilmLanguages"];
                FilmDashboard.FilmPosterImageByte = (byte[])Reader["FilmPosterImageByte"];
                FilmDashboard.FilmPosterImage = RetrieveFilmPoster(FilmDashboard.FilmPosterImageByte);
                model.Add(FilmDashboard);
            }
            connection.Close();
            return View(model);
            
        }

        public string RetrieveFilmPoster(byte[] arrayImage)
        {
            string base64String = Convert.ToBase64String(arrayImage, 0, arrayImage.Length);
            return "data:image/png;base64," + base64String;
        }
    }
}
