﻿using FilmZone.Models;
using Microsoft.AspNetCore.Mvc;
using System.Configuration;
using System.Data.SqlClient;

namespace FilmZone.Controllers
{
    public class AccountController : Controller
    {
        public static string ConnectionString
        {
            get
            {
                return ConfigurationManager.ConnectionStrings["FilmZoneDBConnection"].ConnectionString.ToString();
            }
        }

        SqlConnection connection;
        SqlCommand command = new SqlCommand();
        SqlDataReader Reader;
        public void getconnection()
        {
            connection = new SqlConnection(ConnectionString);
        }


        [HttpGet]
        public ActionResult Login()
        {
            return View();
        }
        

        [HttpPost]
        public ActionResult Login(Logincheck logincheck)
        {
            getconnection();
            connection.Open();
            string query = "Select * from UserAccount where Email='" + logincheck.Email + "' and Password='" + logincheck.Password + "'";
            command = new SqlCommand(query, connection);
            Reader = command.ExecuteReader();
            if (Reader.Read())
            {
                connection.Close();
                return View("Main");
            }
            else
            {
                connection.Close();
                return View("Login");
            }
        }

        [HttpGet]
        public ActionResult Register()
        {
            return View("Registerform");
        }

        [HttpPost]
        public ActionResult Registerform(Account account)
        {
            getconnection();
            connection.Open();
            string query = "Insert into UserAccount values('" + account.FullName + "','" + account.Email + "','" + account.Mobileno + "','" + account.Country + "','" + account.City + "','" + account.Password + "','" + account.ConfirmPassword + "','" + account.Gender + "')";
            command = new SqlCommand(query, connection);
            command.ExecuteNonQuery();
            connection.Close();
            return View("Login");

        }
    }
}
